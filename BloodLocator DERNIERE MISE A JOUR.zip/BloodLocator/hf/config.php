<?php
define('BASE_URL', '/BloodLocator/');
